age = eval(input("how old are you?"))

# age = float(age)

print(age)

print(type(age))

# age = age / 2

# print("new age: ", age)



your_age = eval(input("how old is the second user? "))

if age > your_age:
    print("first person is older")
    print("first person is older")
    print("first person is older")
    print("first person is older")
    print("first person is older")
    print("first person is older")
    print("first person is older")
    print("first person is older")
    print("first person is older")
    print("first person is older")
    print("first person is older")
    
else:
    print("secon person is older")
    
    
print("over")



# for i in range(10000000):
#     x = i ** i
#     print(x)
    
    

address = input("Enter the North/South Component of your address: ")
print(type(address))

num_addr_noso = eval(address)
print(type(num_addr_noso))

#min
mn = min(1,2,3,4,5,-5)
print("mn: ", mn)

#max
mx = max(1,2,3,4,5,-5)
print("mx: ", mx)

# range
r = range(3,11)
print("r: ", r)

for i in range(10):
    print(i)
# how to use floats and range() function
# not in the content videos
lst = [x * 0.1 for x in range(11)]
print(lst)


input("press enter to complete program...")