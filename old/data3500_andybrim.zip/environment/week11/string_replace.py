sentence = "This class is mmmmbooooring!!!!"

sentence.replace("mmmmbooooring", "amazing")

print(sentence)

sentence = sentence.replace("mmmmbooooring", "amazing")

print(sentence)


sentence2 = "1 2 3 4 5 6 7 8"
sentence2 = sentence2.replace(" ", ", ")
print(sentence2)