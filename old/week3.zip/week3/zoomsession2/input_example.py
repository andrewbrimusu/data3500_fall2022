your_name = input("Please enter your name: ")
print("hi", your_name, "thanks for coming!")

your_age = input("Please enter your age: ")
print(type(your_age))
your_age = float(your_age)
print(type(your_age))

print("you are", your_age, "years old.  That is awesome!")

print("in one year, you are going to be", your_age + 1, "years old. great!")


age_desired = eval(input("Enter the age you'd like to live to?"))
print("age_desired: ", age_desired)
print(type(age_desired))

