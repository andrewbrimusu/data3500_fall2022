

import append_data


# call append_data.py to make sure I have new data
# run strategies: sma, mr, bb

