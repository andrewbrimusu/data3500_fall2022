fav_color = "aggie blue"

if fav_color == "aggie blue":
    print("Go Aggies")
else:
    print("Have a nice day!")
    
print(fav_color == "aggie blue")
print(fav_color == "Ute red")

grade = 95
if grade >= 90:
    print('A')
elif grade >= 80:
    print('B')
elif grade >= 70:
    print('C')
elif grade >= 60:
    print('D')
else:
    print('F')
    
    

last_bucket = 5

if last_bucket >= 1:
    print("You win a stunt buggy")
    
if last_bucket >= 2:
    print("You win a board game")
    
if last_bucket >= 3:
    print("You win a football")
    
if last_bucket >= 4:
    print("You win a slip and slide")
    
if last_bucket >= 5:
    print("You win a bike!")

if last_bucket >= 6:
    print("You win a $50 bill!!!")
    
age = 40
while age < 100:
    print("you are still enjoying life!", age)
    age = age + 1

print(age)
    

lst = [1,2,3,4,5]

for num  in lst:
    print(num, end=" ")
    
    
for i in range(2,1001,2):
    print(i)
    
print(i)

for i in range(100):
    print(i)
    
print(i)

i = 0
for l in lst:
    print(l)
    i += 1
    
for l2 in lst:
    print(l2)
    i += 1
    
print(i)

    


    
    
    
    
    
    

input("press enter to end program")