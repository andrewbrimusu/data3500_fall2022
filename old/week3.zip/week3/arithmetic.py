'''
This section of comments is for lots of 
information about your program

This would be used at the beginning of your program to give anybody using it
an explanation of what your program does, and how to use it.

'''


# demonstrating arithmetic operators

x = 10 / 3
y = 10 // 3
z = 10 % 3

print("x: ", x)
print("y: ", y)
print("z: ", z)

a = 3 ** 4
print("a: ", a)


# for i in range(1000000):
#     a = 2 ** i
#     print("a: ", a)

name = "Andy Brim"
gender = 'm'

print(name, gender)

phrase = "Then Andy said 'hi!' "
print("phrase: ", phrase)

phrase_again = "Then Andy said \"hi!\" "
print("phrase_again: ", phrase_again)



