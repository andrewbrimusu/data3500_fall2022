greatest_value = max(1,2,3,4,5,6)
print(greatest_value)

lowest_value = min(1,2,3,4,5,6)
print(lowest_value)

rng = range(6)
print("rng: ", rng)

# range is a list of numbers
for i in rng:
    print(i)
    