var = 1
for i in range(10, 100):
    for j in range(10, 100):
        for k in range(10, 100):
            for l in range(10, 100):
                for m in range(10, 100):
                    var *= i*j*k*l*m
                    print(var)
                        
                        
                    
print("press any key to continue")                    
        
        
        
    
    