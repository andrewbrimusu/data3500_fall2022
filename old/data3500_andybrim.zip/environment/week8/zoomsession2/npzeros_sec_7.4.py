import numpy

# import os
# os.system("sudo pip3 install numpy")



# initialize a numpyarray of size 10
np1 = numpy.zeros(100)
print(np1)


for i in range(100):
    np1[i] = 3.1415
    
print(np1)



















# checkpoint activity
# create a numpy and initilize to 17 zeros







# solution
arr = numpy.zeros(17)