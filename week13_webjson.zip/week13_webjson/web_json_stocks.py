import requests
import json

ticker = 'AAPL'
url = 'http://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol='+ticker+'&outputsize=full&apikey=NG9C9EPVYBMQT0C8'
req = requests.get(url)
time.sleep(12)

# print(req.text)

key1 = "Time Series (Daily)"
keyo = "1. open"
keyh = "2. high"
keyl = "3. low"
keyc = "4. close"

req_dct = json.loads(req.text)

stocks_csv = open(ticker + ".csv", "a")
stocks_csv.write("date,open,high,low,close\n")

# for date in req_dct[key1]:
#     stocks_csv.write(date + "," + req_dct[key1][date][keyo] + "\n")

lines = []
for date in req_dct[key1]: 
    lines.append(date + "," + req_dct[key1][date][keyo] + "," +\
        req_dct[key1][date][keyh] + "," +\
        req_dct[key1][date][keyl] + "," +\
        req_dct[key1][date][keyc] + "\n")
lines.reverse()

for line in lines:
    stocks_csv.write(line)
    

# prices = [ float(req_dct[key1][date][key2]) for date in req_dct[key1] ]
# prices.reverse() # reversing prices so the oldest prices are at the beginning of the list
# print(prices)


