

'''
This is the code for week3 zoomsession1
variables and assignment

'''

# creating and storing variables for my name
first_name = "andy"
last_name = "brim"

full_name = first_name + " " + last_name
print(full_name)

print(type(first_name))



# demonstrating dynamic typing in python
age = 40

print(type(age))

print(type(3.1415926535))

age = "forty"

print("\"age: \"", age)

print(type(age))

# arithmetic

print(2 + 4)
print(2 - 4)
print(2 / 4)
print(2 * 4)

print(4 / 2)
print(type(4 / 2))

print(2 ** 3)

print(7 // 3)
print(7 % 3)


input("press any key...")













# hw question 2.3
print("hello", "world", 5)


# hw question 2.4
print("-----")
