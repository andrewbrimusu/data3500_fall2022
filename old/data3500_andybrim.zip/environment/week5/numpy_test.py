import numpy

# numpy.hello()

print(numpy.mean([1,2,3,4,5]))

