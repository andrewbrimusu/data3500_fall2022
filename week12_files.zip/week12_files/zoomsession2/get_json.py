import numpy as np
import requests
import json

url = "https://api.datamuse.com/words?rel_trg=cow"

req1 = requests.get(url)
dct1 = json.loads(req1.text)

print(dct1)

key1 = "word"
key2 = "score"

for d in dct1:
    if d[key1] == "cheese":
        print("value for cheese: ", d["score"])
        
scores = [ d[key2] for d in dct1]
print(scores)

print("average score: ", sum(scores)/len(scores))