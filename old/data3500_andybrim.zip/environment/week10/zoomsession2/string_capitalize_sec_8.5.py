# captalize function
name = "andy brim"

print(name.capitalize())
print(name.upper())
print(name.lower())

print(name)

name = name.capitalize()
print(name)










# checkpoint activity
# -get string input from the user
# -print the upper case version of the string
# -print the lower case version of the string
# -print the capitalized version of the string (first letter only)

















# solution

string = input("Enter any sentence you want: ")
print(string.upper())
print(string.lower())
print(string.capitalize())