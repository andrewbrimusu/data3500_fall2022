name = "andy"
print("name: ", name)

print(type(name))

name = 35
print("name: ", name)

print(type(name))
