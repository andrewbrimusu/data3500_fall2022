print("age\tmajor\t\tfav_color")
print("andy\tfinance\t\tblue")
print("johnny\taccounting\twhite")

print("number\tsquare\tcube")
print("0\t0\t0")
print("1\t1\t1")