
for k in range(3):
    for i in range(3):
        print("i: ", i)
        if i == 1:
            break
    print("----")
