import os
os.system("sudo pip3 install numpy")
