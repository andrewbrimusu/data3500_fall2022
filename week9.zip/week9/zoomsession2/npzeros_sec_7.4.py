import numpy

# initialize a numpyarray of size 10
np1 = numpy.zeros(100)
print(np1)






















# checkpoint activity
# create a numpy and initilize to 17 zeros







# solution
arr = numpy.zeros(17)