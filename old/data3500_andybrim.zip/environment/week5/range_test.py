print(range(100))

little_pigs = 3

print(little_pigs)

for i in range(2,101,2):
    print(i, end= " ")
    
step = -2
for i in range(-1,-10,step):
    print(i, end= " ")
    
for i in range(10):
    i = i + 1
    print(i)
    
for i in range(-1,-10):
    print(i)
    
print(len(range(-1,-10)))