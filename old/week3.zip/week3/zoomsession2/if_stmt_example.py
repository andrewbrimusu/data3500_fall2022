my_age = 39
your_age = 39

print(my_age > your_age)
print(my_age < your_age)

if my_age > your_age:
    print("I am older")
else:
    print("I am younger")

if my_age == your_age:
    print("We are the same age")
    