print("name\tage\tbirthday")
print("andy\t40\t08/14/1981")
print("madison\t22\t07/24/1999")

print("anna\t", 22, "\t06/11/1999", sep="")
print("andy brim", end="")
print("next line")

    

    