sentence = "I think I'm gonna like it here gonnagonna"

print(sentence.index("gonna"))
print(sentence.rindex("gonna"))


if "like" in sentence:
    print("like " + " is in " + sentence)
    
    
print(sentence.index("I"))
print(sentence.rindex("I"))

